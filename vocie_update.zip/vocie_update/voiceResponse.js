// VoiceResponse - Compatibil Twilio, pentru NextGenSwitch
class VoiceResponse {
  constructor() {
    this.response = { Say: [], Play: [], Gather: [], Dial: [], Record: [], Hangup: false };
  }

  say(text, options = {}) {
    const sayEl = { text, loop: options.loop || 1 };
    this.response.Say.push(sayEl);
    return this;
  }

  play(url, options = {}) {
    this.response.Play.push({ url, loop: options.loop || 1 });
    return this;
  }

  gather(options = {}) {
    const gatherEl = {
      action: options.action,
      method: options.method || 'POST',
      maxDigits: options.maxDigits,
      timeout: options.timeout || 5,
      input: options.input || 'dtmf',
      children: []
    };
    this.response.Gather.push(gatherEl);
    return {
      say: (text) => {
        gatherEl.children.push({ Say: { text } });
        return this;
      }
    };
  }

  dial(options = {}) {
    this.response.Dial.push({
      to: options.to,
      answerOnBridge: options.answerOnBridge || false,
      record: options.record || 'do-not-record'
    });
    return this;
  }

  record(options = {}) {
    this.response.Record.push({
      action: options.action,
      method: options.method || 'POST',
      timeout: options.timeout || 5,
      finishOnKey: options.finishOnKey || '#',
      beep: options.beep || true
    });
    return this;
  }

  hangup() {
    this.response.Hangup = true;
    return this;
  }

  toString() {
    // Generează XML compatibil NGS/Twilio
    let xml = '<?xml version="1.0" encoding="UTF-8"?>\n<Response>\n';
    
    this.response.Say.forEach(s => {
      xml += `  <Say loop="${s.loop}">${s.text}</Say>\n`;
    });
    
    this.response.Play.forEach(p => {
      xml += `  <Play loop="${p.loop}">${p.url}</Play>\n`;
    });
    
    this.response.Gather.forEach(g => {
      xml += `  <Gather action="${g.action}" method="${g.method}" maxDigits="${g.maxDigits}" timeout="${g.timeout}" input="${g.input}">\n`;
      g.children.forEach(child => {
        if (child.Say) xml += `    <Say>${child.Say.text}</Say>\n`;
      });
      xml += '  </Gather>\n';
    });
    
    this.response.Dial.forEach(d => {
      xml += `  <Dial to="${d.to}" answerOnBridge="${d.answerOnBridge}" record="${d.record}" />\n`;
    });
    
    this.response.Record.forEach(r => {
      xml += `  <Record action="${r.action}" method="${r.method}" timeout="${r.timeout}" finishOnKey="${r.finishOnKey}" beep="${r.beep}" />\n`;
    });
    
    if (this.response.Hangup) xml += '  <Hangup/>\n';
    
    xml += '</Response>';
    return xml;
  }
}

module.exports = VoiceResponse;