// NextGenSwitch Service - Înlocuiește complet Twilio
const axios = require('axios');
const logger = require('../utils/logger');

class NextGenSwitchService {
  constructor() {
    this.baseURL = process.env.NGS_BASE_URL || 'http://localhost:8080';
    this.authId = process.env.NGS_AUTH_ID;
    this.authSecret = process.env.NGS_AUTH_SECRET;
    this.phoneNumber = process.env.NGS_PHONE_NUMBER || '+37368467729';
  }

  // ---------- OUTBOUND CALL (înlocuiește client.calls.create) ----------
  async createCall(params) {
    const { to, from, statusCallback, responseXml, response } = params;
    
    const formData = new URLSearchParams();
    formData.append('to', to);
    formData.append('from', from || this.phoneNumber);
    if (statusCallback) formData.append('statusCallback', statusCallback);
    if (responseXml) formData.append('responseXml', responseXml);
    if (response) formData.append('response', response);
    
    try {
      const result = await axios({
        method: 'POST',
        url: `${this.baseURL}/api/v1/call`,
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
          'X-Authorization': this.authId,
          'X-Authorization-Secre': this.authSecret
        },
        data: formData
      });
      
      logger.info('NGS outbound call created', { callId: result.data?.call_id });
      return { sid: result.data?.call_id || result.data }; // Compatibilitate cu codul existent
    } catch (error) {
      logger.error('NGS createCall error:', error);
      throw error;
    }
  }

  // ---------- MODIFY LIVE CALL (înlocuiește call.update) ----------
  async modifyCall(callId, responseXml) {
    try {
      const result = await axios({
        method: 'PUT',
        url: `${this.baseURL}/api/v1/call/${callId}`,
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
          'X-Authorization': this.authId,
          'X-Authorization-Secre': this.authSecret
        },
        data: new URLSearchParams({ responseXml })
      });
      
      return result.data;
    } catch (error) {
      logger.error('NGS modifyCall error:', error);
      throw error;
    }
  }

  // ---------- GENEREAZĂ XML (IDENTIC CU TWILIO) ----------
  buildResponse() {
    const VoiceResponse = require('./VoiceResponse'); // Vezi mai jos
    return new VoiceResponse();
  }
}

module.exports = new NextGenSwitchService();