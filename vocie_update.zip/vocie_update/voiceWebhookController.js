// ÎN LOC DE:
- const twilio = require('twilio');
- const VoiceResponse = twilio.twiml.VoiceResponse;

// ADAUGĂ:
const VoiceResponse = require('../services/VoiceResponse');
const ngsService = require('../services/nextgenswitch');

// LA METODA transferToHuman, SCHIMBĂ:
  async transferToHuman(callSid) {
-   const twilioClient = twilio(...);
-   await twilioClient.calls(callSid).update({ twiml: ... });
    
+   const xml = new VoiceResponse()
+     .say('Vă transfer la un operator. Vă rugăm să așteptați.')
+     .dial({ to: process.env.HUMAN_AGENT_PHONE_NUMBER })
+     .toString();
+   
+   await ngsService.modifyCall(callSid, xml);
    
    return 'Vă conectez cu un operator. Un moment, vă rog.';
  }